/**
* \file dod_funkcje.cpp
* \author Kamil Dawid�w & Beata Gie�baga
* \date 15.5.2014
* \brief Definicje funkcji pomocniczych
*/
// ------------------------------------------------------

#include "dod_funkcje.h"

int conversion(char right)
{
    return right - 97;
}

char conversion(int right)
{
    return right + 97;
}